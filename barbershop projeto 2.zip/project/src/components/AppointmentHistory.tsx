import React, { useState, useEffect } from 'react';
import { Calendar, Clock, CheckCircle, XCircle, AlertCircle } from 'lucide-react';
import { Appointment, Service } from '../types';
import { useAuth } from '../contexts/AuthContext';

const services: Service[] = [
  {
    id: '1',
    name: 'Corte Tradicional',
    description: 'Corte clássico com acabamento',
    duration: 30,
    price: 25
  },
  {
    id: '2',
    name: 'Corte + Barba',
    description: 'Corte completo com barba alinhada',
    duration: 45,
    price: 40
  },
  {
    id: '3',
    name: 'Barba',
    description: 'Aparar e alinhar barba',
    duration: 20,
    price: 20
  },
  {
    id: '4',
    name: 'Corte Premium',
    description: 'Corte moderno com styling',
    duration: 60,
    price: 50
  }
];

export const AppointmentHistory: React.FC = () => {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const { user } = useAuth();

  useEffect(() => {
    if (user) {
      const storedAppointments = JSON.parse(localStorage.getItem('barbershop_appointments') || '[]');
      const userAppointments = storedAppointments.filter((apt: Appointment) => apt.userId === user.id);
      setAppointments(userAppointments.sort((a: Appointment, b: Appointment) => 
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      ));
    }
  }, [user]);

  const getStatusIcon = (status: Appointment['status']) => {
    switch (status) {
      case 'confirmed':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'completed':
        return <CheckCircle className="w-5 h-5 text-blue-500" />;
      case 'cancelled':
        return <XCircle className="w-5 h-5 text-red-500" />;
      default:
        return <AlertCircle className="w-5 h-5 text-yellow-500" />;
    }
  };

  const getStatusText = (status: Appointment['status']) => {
    switch (status) {
      case 'confirmed':
        return 'Confirmado';
      case 'completed':
        return 'Concluído';
      case 'cancelled':
        return 'Cancelado';
      default:
        return 'Pendente';
    }
  };

  const getStatusColor = (status: Appointment['status']) => {
    switch (status) {
      case 'confirmed':
        return 'bg-green-100 text-green-800';
      case 'completed':
        return 'bg-blue-100 text-blue-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-yellow-100 text-yellow-800';
    }
  };

  if (appointments.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow-md p-8 text-center">
        <Calendar className="w-16 h-16 text-gray-300 mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-gray-800 mb-2">Nenhum agendamento encontrado</h2>
        <p className="text-gray-600">
          Você ainda não fez nenhum agendamento. Que tal reservar um horário?
        </p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-bold text-gray-800 mb-6">Histórico de Agendamentos</h2>
      
      <div className="space-y-4">
        {appointments.map((appointment) => {
          const service = services.find(s => s.id === appointment.serviceId);
          const appointmentDate = new Date(appointment.date);
          const isUpcoming = appointmentDate > new Date();
          
          return (
            <div
              key={appointment.id}
              className={`border rounded-lg p-4 ${isUpcoming ? 'border-amber-200 bg-amber-50' : 'border-gray-200'}`}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center mb-2">
                    <h3 className="text-lg font-semibold text-gray-800">
                      {service?.name || 'Serviço não encontrado'}
                    </h3>
                    <div className="ml-3 flex items-center">
                      {getStatusIcon(appointment.status)}
                      <span className={`ml-1 px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(appointment.status)}`}>
                        {getStatusText(appointment.status)}
                      </span>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-600">
                    <div className="flex items-center">
                      <Calendar className="w-4 h-4 mr-2" />
                      {appointmentDate.toLocaleDateString('pt-BR')}
                    </div>
                    <div className="flex items-center">
                      <Clock className="w-4 h-4 mr-2" />
                      {appointment.time}
                    </div>
                    <div className="font-semibold text-amber-600">
                      R$ {service?.price || 0}
                    </div>
                  </div>
                  
                  {service?.description && (
                    <p className="text-sm text-gray-500 mt-2">{service.description}</p>
                  )}
                </div>
              </div>
              
              <div className="mt-3 pt-3 border-t border-gray-200 text-xs text-gray-500">
                Agendado em: {new Date(appointment.createdAt).toLocaleDateString('pt-BR')} às {new Date(appointment.createdAt).toLocaleTimeString('pt-BR')}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};