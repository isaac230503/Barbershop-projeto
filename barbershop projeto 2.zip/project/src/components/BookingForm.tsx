import React, { useState } from 'react';
import { Clock, CheckCircle } from 'lucide-react';
import { Service, TimeSlot, Appointment } from '../types';
import { useAuth } from '../contexts/AuthContext';

const services: Service[] = [
  {
    id: '1',
    name: 'Corte Tradicional',
    description: 'Corte clássico com acabamento',
    duration: 30,
    price: 25
  },
  {
    id: '2',
    name: 'Corte + Barba',
    description: 'Corte completo com barba alinhada',
    duration: 45,
    price: 40
  },
  {
    id: '3',
    name: 'Barba',
    description: 'Aparar e alinhar barba',
    duration: 20,
    price: 20
  },
  {
    id: '4',
    name: 'Corte Premium',
    description: 'Corte moderno com styling',
    duration: 60,
    price: 50
  }
];

const generateTimeSlots = (): TimeSlot[] => {
  const slots: TimeSlot[] = [];
  const startHour = 9;
  const endHour = 18;
  
  for (let hour = startHour; hour < endHour; hour++) {
    for (let minute = 0; minute < 60; minute += 30) {
      const time = `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
      slots.push({
        time,
        available: Math.random() > 0.3 // 70% chance of being available
      });
    }
  }
  
  return slots;
};

export const BookingForm: React.FC = () => {
  const [selectedService, setSelectedService] = useState<string>('');
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [selectedTime, setSelectedTime] = useState<string>('');
  const [timeSlots] = useState<TimeSlot[]>(generateTimeSlots());
  const [isBooking, setIsBooking] = useState(false);
  const [bookingSuccess, setBookingSuccess] = useState(false);
  const { user } = useAuth();

  const today = new Date();
  const maxDate = new Date();
  maxDate.setDate(today.getDate() + 30);

  const handleBooking = async () => {
    if (!selectedService || !selectedDate || !selectedTime || !user) return;

    setIsBooking(true);
    
    // Simular reserva
    await new Promise(resolve => setTimeout(resolve, 2000));

    const appointment: Appointment = {
      id: Date.now().toString(),
      userId: user.id,
      serviceId: selectedService,
      date: selectedDate,
      time: selectedTime,
      status: 'pending',
      createdAt: new Date().toISOString()
    };

    // Salvar no localStorage
    const appointments = JSON.parse(localStorage.getItem('barbershop_appointments') || '[]');
    appointments.push(appointment);
    localStorage.setItem('barbershop_appointments', JSON.stringify(appointments));

    setIsBooking(false);
    setBookingSuccess(true);

    // Reset form após 3 segundos
    setTimeout(() => {
      setBookingSuccess(false);
      setSelectedService('');
      setSelectedDate('');
      setSelectedTime('');
    }, 3000);
  };

  if (bookingSuccess) {
    return (
      <div className="bg-white rounded-lg shadow-md p-8 text-center">
        <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-gray-800 mb-2">Agendamento Confirmado!</h2>
        <p className="text-gray-600 mb-4">
          Seu horário foi reservado para {new Date(selectedDate).toLocaleDateString('pt-BR')} às {selectedTime}
        </p>
        <div className="animate-pulse">
          <div className="h-2 bg-amber-200 rounded-full">
            <div className="h-2 bg-amber-600 rounded-full animate-pulse" style={{ width: '100%' }}></div>
          </div>
          <p className="text-sm text-gray-500 mt-2">Retornando ao formulário...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-bold text-gray-800 mb-6">Agendar Horário</h2>
      
      <div className="space-y-6">
        {/* Seleção de Serviço */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-3">
            Escolha o Serviço
          </label>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {services.map((service) => (
              <div
                key={service.id}
                onClick={() => setSelectedService(service.id)}
                className={`p-4 border-2 rounded-lg cursor-pointer transition-all hover:shadow-md ${
                  selectedService === service.id
                    ? 'border-amber-500 bg-amber-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <h3 className="font-semibold text-gray-800">{service.name}</h3>
                <p className="text-sm text-gray-600 mb-2">{service.description}</p>
                <div className="flex justify-between items-center">
                  <span className="flex items-center text-sm text-gray-500">
                    <Clock className="w-4 h-4 mr-1" />
                    {service.duration} min
                  </span>
                  <span className="font-bold text-amber-600">R$ {service.price}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Seleção de Data */}
        {selectedService && (
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Escolha a Data
            </label>
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              min={today.toISOString().split('T')[0]}
              max={maxDate.toISOString().split('T')[0]}
              className="w-full md:w-auto px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent"
            />
          </div>
        )}

        {/* Seleção de Horário */}
        {selectedDate && (
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Horários Disponíveis
            </label>
            <div className="grid grid-cols-3 md:grid-cols-6 gap-2">
              {timeSlots.map((slot) => (
                <button
                  key={slot.time}
                  onClick={() => slot.available && setSelectedTime(slot.time)}
                  disabled={!slot.available}
                  className={`p-2 text-sm rounded-lg border transition-all ${
                    selectedTime === slot.time
                      ? 'bg-amber-500 text-white border-amber-500'
                      : slot.available
                      ? 'bg-white text-gray-700 border-gray-300 hover:border-amber-300 hover:bg-amber-50'
                      : 'bg-gray-100 text-gray-400 border-gray-200 cursor-not-allowed'
                  }`}
                >
                  {slot.time}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Botão de Confirmação */}
        {selectedService && selectedDate && selectedTime && (
          <div className="pt-4 border-t">
            <div className="bg-gray-50 rounded-lg p-4 mb-4">
              <h3 className="font-semibold text-gray-800 mb-2">Resumo do Agendamento:</h3>
              <div className="space-y-1 text-sm text-gray-600">
                <p><strong>Serviço:</strong> {services.find(s => s.id === selectedService)?.name}</p>
                <p><strong>Data:</strong> {new Date(selectedDate).toLocaleDateString('pt-BR')}</p>
                <p><strong>Horário:</strong> {selectedTime}</p>
                <p><strong>Valor:</strong> R$ {services.find(s => s.id === selectedService)?.price}</p>
              </div>
            </div>
            
            <button
              onClick={handleBooking}
              disabled={isBooking}
              className="w-full py-3 bg-gradient-to-r from-amber-500 to-amber-600 text-white font-semibold rounded-lg hover:from-amber-600 hover:to-amber-700 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:ring-offset-2 transition-all transform hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isBooking ? 'Confirmando...' : 'Confirmar Agendamento'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};